
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Временное хранилище в памяти
requests_data = []

@app.route('/api/notify', methods=['POST'])
def notify():
    data = request.json
    data["status"] = {}  # купил, написал в поддержку и т.д.
    requests_data.append(data)
    return jsonify({"success": True})

@app.route('/api/requests', methods=['GET'])
def get_requests():
    return jsonify(requests_data)

@app.route('/api/update', methods=['POST'])
def update_status():
    data = request.json
    tg_id = data.get("tg_id")
    key = data.get("key")
    value = data.get("value")
    for r in requests_data:
        if r.get("tg_id") == tg_id:
            r["status"][key] = value
    return jsonify({"success": True})

if __name__ == "__main__":
    app.run(debug=True)
